from datetime import datetime, timedelta
from flask import Flask, jsonify, request 
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Sequence
from sqlalchemy import func 
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from datetime import datetime , timedelta
from datetime import datetime, timedelta
from collections import defaultdict





app = Flask(__name__)
app.secret_key = 'abcd'
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///userdata.db"
db = SQLAlchemy(app)
app.app_context().push()
jwt = JWTManager(app)
app.config['JWT_SECRET_KEY'] = 'your_secret_key'


app.config.from_object(__name__)

CORS(app, resources={r"/*":{'origins':"*"}})



class UserData(db.Model):
    fullName = db.Column(db.String(30))
    email = db.Column(db.String(30) , primary_key = True)
    passw = db.Column(db.String(30))
    mobile = db.Column(db.String(30))
    designation = db.Column(db.String(30))


class AdminData(db.Model):
    fullName = db.Column(db.String(30))
    email = db.Column(db.String(30) , primary_key = True)
    passw = db.Column(db.String(30))
    mobile = db.Column(db.String(30))


class Ebooks(db.Model):
    ebid = db.Column(db.String(30), primary_key = True)
    name = db.Column(db.String(30) )
    genre = db.Column(db.String(30))
    content = db.Column(db.Text)
    description = db.Column(db.Text)
    authors = db.Column(db.String(30))
    price = db.Column(db.Integer)
    rental = db.Column(db.Integer)


class Addebokreq(db.Model):
    ebid = db.Column(db.String(30), primary_key = True)
    name = db.Column(db.String(30) )
    genre = db.Column(db.String(30))
    content = db.Column(db.Text)
    description = db.Column(db.Text)
    authors = db.Column(db.String(30))
    price = db.Column(db.Integer)
    rental = db.Column(db.Integer)
    requser = db.Column(db.String(30))


class Section(db.Model):
    scid = db.Column(db.String(30), primary_key=True)
    name = db.Column(db.String(30) )
    scd = db.Column(db.DateTime , default = datetime.utcnow)   #section creation date
    desc = db.Column(db.Text)

class Issreq(db.Model):   #for issueng requests
    s_no = db.Column(db.Integer , primary_key = True)
    requsr = db.Column(db.String(30))
    reqebookid = db.Column(db.String(30))
    reqebooknm = db.Column(db.String(30))
    reqdtm = db.Column(db.DateTime , default = datetime.utcnow)


#for book approval
#here are the book which are issued to any specifc user


class Appissue(db.Model):
    s_no = db.Column(db.Integer, primary_key=True)
    ebid = db.Column(db.String(30))
    name = db.Column(db.String(30))
    usr = db.Column(db.String(30))
    issdt = db.Column(db.DateTime, default=datetime.utcnow)
    rtdt = db.Column(db.DateTime, default=lambda: datetime.utcnow() + timedelta(days=7))



class Issuelog(db.Model):
    s_no = db.Column(db.Integer, primary_key=True)
    ebid = db.Column(db.String(30))
    name = db.Column(db.String(30))
    usr = db.Column(db.String(30))
    issdt = db.Column(db.DateTime)
    rtdt = db.Column(db.DateTime)




class UserMessage(db.Model):
    sno = db.Column(db.Integer, Sequence('user_message_sno_seq'), primary_key=True)
    usr = db.Column(db.String(30))
    msg = db.Column(db.Text)




    





# hello world route
@app.route('/', methods=['GET'])
def greetings():
    return("Hello, world! backend is working prefectly")




# step 5 wala function h isme 
@jwt.user_identity_loader
def user_identity_lookup(user):
    return user.email

def generate_token(user):
    access_token = create_access_token(identity=user)
    return access_token


#step 6 wala h ye 
@app.route('/protected', methods=['GET'])
@jwt_required()
def protected():
    current_user = get_jwt_identity()
    print(current_user)
    cuser = UserData.query.filter_by(email=current_user).first()
    user_data_dict = {
        'fullName': cuser.fullName,
        'email': cuser.email,
        'passw':cuser.passw,
        'mobile':cuser.mobile,
        'des':cuser.designation
        # Add other attributes as needed
    }
    return jsonify(user_data_dict)


@app.route('/ebooks', methods=['GET'])
@jwt_required()
def avlebook():
    current_user = get_jwt_identity()
    print(current_user)
    avl_book = Ebooks.query.all()
    ael=[]
    for x in avl_book:
        
        teb={
            'id':x.ebid,
            'name':x.name,
            'content':x.content,
            'description':x.description,
            'genre':x.genre,
            'authors':x.authors,
            'price':x.price,
            'rental':x.rental}

        ael.append(teb)
    print(ael)
      
    
    
    return jsonify(ael)



@app.route('/allebooks', methods=['GET'])
def get_all_ebooks():
    try:
        all_ebooks = Ebooks.query.all()
        ebooks_list = []
        for ebook in all_ebooks:
            ebooks_list.append({
                'ebid': ebook.ebid,
                'name': ebook.name,
                'genre': ebook.genre,
                'content': ebook.content,
                'description': ebook.description,
                'authors': ebook.authors,
                'price': ebook.price,
                'rental': ebook.rental
            })
        return jsonify(ebooks_list)
    except Exception as e:
        return jsonify({'error': str(e)}), 500



# buying book request 



@app.route('/rentbookreq', methods=['POST'])
@jwt_required()
def buy_book():
    current_user = get_jwt_identity()
    data = request.json
    print(data , current_user)



    
    treq = Issreq(requsr = current_user , reqebookid = data['reqbbid'] , reqebooknm = data['reqbnm'] )
    db.session.add(treq)
    db.session.commit()


    return jsonify({'status': 'success'})





@app.route('/reqbooks', methods=['GET'])
@jwt_required()
def reqbook():
    current_user = get_jwt_identity()
    reqbob = Issreq.query.filter_by(requsr=current_user)

    l = []

    for x in reqbob:
        l.append(x.reqebookid)

    #return jsonify({'status':'success'})
    return jsonify(l)




@app.route('/reqbooksissuel', methods=['GET'])
@jwt_required()
def reqbookissuel():
    current_user = get_jwt_identity()
    reqbob = Appissue.query.filter_by(usr=current_user)

    l = []

    for x in reqbob:
        l.append(x.ebid)

    #return jsonify({'status':'success'})
    return jsonify(l)


#fetcing pending approvals for publishing ebook which will be approved by user
#yaha par kooch changes karna hai jsi se 
#jo return data jaayega uska poora systumm kharaab hai
#ye h book issue k liye 


@app.route('/ebookissuereq', methods=['GET'])
@jwt_required()
def ebookissuereq():
    try:
        current_user = get_jwt_identity()
        reqebook = Issreq.query.all()
        l = []

        for x in reqebook:
            teb = {
                's_no': x.s_no , 
                'requsr':x.requsr ,
                'reqebookid' : x.reqebookid ,
                'reqebooknm' : x.reqebooknm ,



                
                
            }
            l.append(teb)
        print(l)
        return jsonify(l), 200
    except Exception as e:
        print(e)  # Log the exception to console
        return jsonify({'error': 'An error occurred'}), 500 
    


#book publish requests
    





@app.route('/ebookpubappreq', methods=['GET'])
@jwt_required()
def ebookpubreq():
    try:
        current_user = get_jwt_identity()
        reqebook = Addebokreq.query.all()
        l = []

        for x in reqebook:
            teb = {
                'ebid': x.ebid,
                'name': x.name,
                'genre': x.genre,
                'content': x.content,
                'description': x.description,
                'authors': x.authors,
                'price': x.price,
                'rental': x.rental,
                'requser': x.requser
            }
            l.append(teb)

        return jsonify(l), 200
    except Exception as e:
        print(e)  # Log the exception to console
        return jsonify({'error': 'An error occurred'}), 500 
    







@app.route('/addebook', methods=['POST'])
@jwt_required()
def add_ebook():
    current_user = get_jwt_identity()
    data = request.json
    
    # Extract data from the request
    ebid = data.get('ebid')
    name = data.get('name')
    genre = data.get('genre')
    description = data.get('description')
    content = data.get('content')
    authors = data.get('authors')
    price = data.get('price')
    rental = data.get('rental')
    # Create a new Ebooks object
    new_ebook = Addebokreq(
        ebid=ebid,
        name=name,
        genre=genre,
        description=description,
        content=content,
        authors=authors,
        price = price,
        rental = rental,
        requser=current_user  # Assign the authenticated user's email
    )
    
    # Add the new_ebook to the database session and commit
    db.session.add(new_ebook)
    db.session.commit()
    
    return jsonify({'status': 'success'})






@app.route('/signup', methods=['POST'])
def signup():
    if request.method == 'POST':
        data = request.json

        tname = data['fname']
        temail = data['email']
        tmobile = data['mobile']
        tdes = data['designation']
        tpassw = data['passw']
        

        user = UserData( fullName = tname , email = temail , passw = tpassw , mobile = tmobile , designation = tdes)
        db.session.add(user)
        db.session.commit()
       
        print("Received data:", data)
        
        return jsonify({'message': 'Signup successful verified by backend'}), 200
    else:
        return jsonify({'error': 'Method not allowed'}), 405
    



@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        data = request.json
        lemail = data['lemail']
        lpassw = data['lpassw']
        user = UserData.query.filter_by(email=lemail, passw=lpassw).first()
        if user:
            access_token = generate_token(user)
            print(user)
            return jsonify({'access_token': access_token}), 200
        else:
            print(user)
            return jsonify({'error': 'Invalid credentials'}), 401
    else:
        return jsonify({'error': 'Method not allowed'}), 405


@app.route('/adminlogin', methods=['POST'])
def adminlogin():
    if request.method == 'POST':
        data = request.json
        lemail = data['lemail']
        lpassw = data['lpassw']
        print(lemail , lpassw)
        user = AdminData.query.filter_by(email=lemail, passw=lpassw).first()
        if user:
            access_token = generate_token(user)
            
            print(user)
            return jsonify({'access_token': access_token}), 200
        else:
            print(user)
            return jsonify({'error': 'Invalid credentials'}), 401
    else:
        return jsonify({'error': 'Method not allowed'}), 405
    




@app.route('/approveBook/<e>', methods=['GET'])
@jwt_required()

def approve_book(e):
    

    current_user = get_jwt_identity()
    print(current_user)
    if current_user:
        # Here you can use the value of `e` for further processing
        # For demonstration, let's just return a simple response
        print("here we are getting book which need to be approved")
        print(e)
        ibook = Addebokreq.query.filter_by(ebid=e).first()
        tm = f"a new book which you requested ie {ibook.name} is approved successfully"
        target_usr = ibook.requser

        print(tm)
        jbook = Ebooks(ebid = ibook.ebid , name = ibook.name , genre = ibook.genre , content = ibook.content , description = ibook.description , authors = ibook.authors , price = ibook.price , rental = ibook.rental  )
        db.session.add(jbook)
        db.session.delete(ibook)
        db.session.commit()


        tmsg = UserMessage(usr = target_usr , msg = tm)
        db.session.add(tmsg)
        db.session.commit()


        return jsonify({"message": f"Book with id {e} approved."})
    else:
        return jsonify({"error": "Unauthorized"}), 401




@app.route('/rejectBook/<e>', methods=['GET'])
@jwt_required()

def reject_book(e):
    

    current_user = get_jwt_identity()
    print(current_user)
    if current_user:
        # Here you can use the value of `e` for further processing
        # For demonstration, let's just return a simple response
        print("here we are getting book which need to be rejected")
        print(e)
        ibook = Addebokreq.query.filter_by(ebid=e).first()
        target_usr = ibook.requser
        tm = f"We regret to inform you that the book you submitted ie {ibook.name} has been rejected."

        
        db.session.delete(ibook)
        db.session.commit()


        tmsg = UserMessage(usr = target_usr , msg = tm)
        db.session.add(tmsg)
        db.session.commit()


        return jsonify({"message": f"Book with id {e} approved."})
    else:
        return jsonify({"error": "Unauthorized"}), 401






#below is the code for approving issue request for the dashboard of admin
    

@app.route('/approveBookissue/<e>', methods=['GET'])
@jwt_required()

def approve_book_issue(e):
    

    current_user = get_jwt_identity()
    print(current_user)
    if current_user:
        # Here you can use the value of `e` for further processing
        # For demonstration, let's just return a simple response
        print("here we are getting book which need to be approval for issueing")
        print(e)
        ibook = Issreq.query.filter_by(s_no = e).first()
        target_usr = ibook.requsr

        jbook = Appissue(ebid = ibook.reqebookid , name = ibook.reqebooknm , usr = ibook.requsr )

        tm = f"a new book which you requested ie {ibook.reqebooknm} is issued successfully"
        tmsg = UserMessage(usr = target_usr , msg = tm)
        db.session.add(tmsg)
        



        db.session.add(jbook)
        db.session.delete(ibook)
        db.session.commit()


        return jsonify({"message": f"Book with id {e} approved."})
    else:
        return jsonify({"error": "Unauthorized"}), 401




#here we will define app.route for backend
    




@app.route('/rejectBookissue/<e>', methods=['GET'])
@jwt_required()

def reject_book_issue(e):
    

    current_user = get_jwt_identity()
    print(current_user)
    if current_user:
        # Here you can use the value of `e` for further processing
        # For demonstration, let's just return a simple response
        print("here we are getting book which need to be approval for issueing")
        print(e)
        ibook = Issreq.query.filter_by(s_no = e).first()
        target_usr = ibook.requsr
        

        tm = f"The requested book, {ibook.reqebooknm}, has not been issued."
        tmsg = UserMessage(usr = target_usr , msg = tm)
        db.session.add(tmsg)
        



        
        db.session.delete(ibook)
        db.session.commit()


        return jsonify({"message": f"Book with id {e} approved."})
    else:
        return jsonify({"error": "Unauthorized"}), 401



#this is the app.route for the returning set of book which is issued to any specific user 
#
    



@app.route('/issuedbooks', methods=['GET'])
@jwt_required()
def issued():
    current_user = get_jwt_identity()
    print(current_user)
    spi = Appissue.query.filter_by(usr = current_user)
    bi=[]
    for x in spi:
        bi.append(x.ebid)

    idbk=[]
    
    for i in bi:
        teb = Ebooks.query.filter_by(ebid = i).first()
        ieb={
            'id':teb.ebid,
            'name':teb.name,
            'content':teb.content,
            'description':teb.description,
            'genre':teb.genre,
            'authors':teb.authors,
            'price':teb.price,
            'rental':teb.rental}

        idbk.append(ieb)
    return jsonify(idbk)









@app.route('/messages', methods=['GET'])
@jwt_required()

def fetch_messages():
    # Assuming you have implemented JWT authentication
    current_user = get_jwt_identity()
    if current_user:
        # Fetch messages for the current user
        messages = UserMessage.query.filter_by(usr=current_user).all()
        # Serialize messages to JSON
        serialized_messages = [{
            'sno': message.sno,
            'usr': message.usr,
            'msg': message.msg
        } for message in messages]
        return jsonify(serialized_messages)
    else:
        return jsonify({"error": "Unauthorized"}), 401



    


@app.route('/deleteEbook/<string:ebid>', methods=['DELETE'])
def delete_ebook(ebid):
    ebook = Ebooks.query.get(ebid)
    if ebook:
        db.session.delete(ebook)
        db.session.commit()
        return jsonify({'message': 'Ebook deleted successfully'}), 200
    else:
        return jsonify({'message': 'Ebook not found'}), 404



# Route to revoke an individual issued book
@app.route('/revokeBook/<int:issue_id>', methods=['DELETE'])
@jwt_required()
def revoke_book(issue_id):
    try:
        issue = Appissue.query.get(issue_id)
        if issue:
            # Add the revoked book to Issuelog before deleting
            log_entry = Issuelog(
                ebid=issue.ebid,
                name=issue.name,
                usr=issue.usr,
                issdt=issue.issdt,
                rtdt=issue.rtdt
            )
            db.session.add(log_entry)
            db.session.delete(issue)
            db.session.commit()
            return {"message": "Book revoked successfully"}, 200
        else:
            return {"error": "Issue not found"}, 404
    except Exception as e:
        return {"error": str(e)}, 500

# Route to revoke all issues older than 7 days
@app.route('/revokeAllBooks', methods=['DELETE'])
@jwt_required()
def revoke_all_books():
    try:
        # Get all issues older than 7 days
        older_than_seven_days = Appissue.query.filter(Appissue.issdt < (datetime.utcnow() - timedelta(days=7))).all()
        for issue in older_than_seven_days:
            # Add each revoked book to Issuelog before deleting
            log_entry = Issuelog(
                ebid=issue.ebid,
                name=issue.name,
                usr=issue.usr,
                issdt=issue.issdt,
                rtdt=issue.rtdt
            )
            db.session.add(log_entry)
            db.session.delete(issue)
        db.session.commit()
        return {"message": "All books older than 7 days have been revoked"}, 200
    except Exception as e:
        return {"error": str(e)}, 500

# Route to return a book
@app.route('/returnbook/<name>', methods=['DELETE'])
@jwt_required()
def return_book(name):
    current_user = get_jwt_identity()
    try:
        book_to_return = Appissue.query.filter_by(usr=current_user, name=name).first()
        if book_to_return:
            # Add the returned book to Issuelog before deleting
            log_entry = Issuelog(
                ebid=book_to_return.ebid,
                name=book_to_return.name,
                usr=book_to_return.usr,
                issdt=book_to_return.issdt,
                rtdt=book_to_return.rtdt
            )
            db.session.add(log_entry)
            db.session.delete(book_to_return)
            db.session.commit()
            return {"message": "Book returned successfully"}, 200
        else:
            return {"error": "Book not found"}, 404
    except Exception as e:
        return {"error": str(e)}, 500





# Define route to fetch issued books
@app.route('/issuedbooksad', methods=['GET'])
def get_issued_books_ad():
    issued_books = Appissue.query.all()
    issued_books_data = []
    for book in issued_books:
        issued_books_data.append({
            's_no': book.s_no,
            'name': book.name,
            'usr': book.usr,
            'issdt': book.issdt,
            'rtdt': book.rtdt
        })
    return jsonify(issued_books_data)





@app.route('/addEbookad', methods=['POST'])
def add_ebookad():
    data = request.json
    new_ebook = Ebooks(
        ebid=data['ebid'],
        name=data['name'],
        genre=data['genre'],
        content=data['content'],
        description=data['description'],
        authors=data['authors'],
        price=data['price'],
        rental=data['rental']
    )
    db.session.add(new_ebook)
    db.session.commit()

    sections = Section.query.all()
    section_names = [section.name for section in sections]
    section_id = [section.scid for section in sections]
    if (len(section_id)== 0 ):
        nsc = 1
    else:
        nsc = int(section_id[-1])+1


    if new_ebook.genre not in section_names:
        newsec = Section(name = new_ebook.genre ,scid = nsc )
        db.session.add(newsec)
        db.session.commit()


    return jsonify(message='Ebook added successfully')





@app.route('/addSection', methods=['POST'])
def add_section():
    data = request.json
    new_section = Section(
        scid=data['scid'],
        name=data['name'],
        desc=data['desc']
    )
    db.session.add(new_section)
    db.session.commit()
    return jsonify(message='Section added successfully')




@app.route('/sections', methods=['GET'])
def get_sections():
    sections = Section.query.all()
    section_data = []
    for section in sections:
        section_data.append({
            'scid': section.scid,
            'name': section.name,
            'scd': section.scd.strftime('%Y-%m-%d %H:%M:%S'),
            'desc': section.desc
        })
    return jsonify(section_data)



# Route for deleting a section
@app.route('/deleteSection/<scid>', methods=['DELETE'])
def delete_section(scid):
    section = Section.query.get(scid)
    if section:
        # Find all ebooks with the matching genre
        ebooks_to_delete = Ebooks.query.filter_by(genre=section.name).all()
        
        # Delete all ebooks with the matching genre
        for ebook in ebooks_to_delete:
            db.session.delete(ebook)
        
        # Now delete the section
        db.session.delete(section)
        db.session.commit()
        
        return jsonify({'message': 'Section and associated eBooks deleted successfully'}), 200
    else:
        return jsonify({'error': 'Section not found'}), 404

# Route for updating a section
@app.route('/updateSection/<scid>', methods=['PUT'])
def update_section(scid):
    section = Section.query.get(scid)
    if section:
        data = request.json
        section.name = data.get('name', section.name)
        section.desc = data.get('desc', section.desc)
        db.session.commit()
        return jsonify({'message': 'Section updated successfully'}), 200
    else:
        return jsonify({'error': 'Section not found'}), 404





@app.route('/userissuedata_ad')
def get_user_issue_data():
    try:
        # Query to get counts of issued books per user
        user_issue_data = (
            db.session.query(Appissue.usr, func.count().label('issuedBooksCount'))
            .group_by(Appissue.usr)
            .all()
        )

        # Convert the result to a list of dictionaries
        user_issue_data_dict = [
            {"user": user, "issuedBooksCount": count}
            for user, count in user_issue_data
        ]

        return jsonify(user_issue_data_dict)
    except Exception as e:
        return jsonify({"error": str(e)}), 500




from collections import defaultdict

@app.route('/userissuedata_ad_m')
def month():
    try:
        # Query to get counts of issued books per month
        user_issue_data = (
            db.session.query(func.extract('month', Issuelog.issdt).label('month'), func.count().label('issuedBooksCount'))
            .group_by(func.extract('month', Issuelog.issdt))
            .all()
        )

        # Convert the result to a dictionary with month names
        months_dict = {
            1: 'January',
            2: 'February',
            3: 'March',
            4: 'April',
            5: 'May',
            6: 'June',
            7: 'July',
            8: 'August',
            9: 'September',
            10: 'October',
            11: 'November',
            12: 'December'
        }

        # Group the data by month
        monthly_data = defaultdict(int)
        for month, count in user_issue_data:
            monthly_data[months_dict[month]] = count

        # Convert the data to a list of dictionaries
        result = [{"month": month, "issuedBooksCount": count} for month, count in monthly_data.items()]

        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500





# Endpoint to fetch all eBooks
@app.route('/ebooks', methods=['GET'])
def get_ebooks():
    ebooks = Ebooks.query.all()
    ebook_list = []
    for ebook in ebooks:
        ebook_dict = {
            'ebid': ebook.ebid,
            'name': ebook.name,
            'genre': ebook.genre,
            'content': ebook.content,
            'description': ebook.description,
            'authors': ebook.authors,
            'price': ebook.price,
            'rental': ebook.rental
        }
        ebook_list.append(ebook_dict)
    return jsonify(ebook_list)



# Update eBook route
@app.route('/updateEbook/<ebid>', methods=['PUT'])
def update_ebook(ebid):
    ebook = Ebooks.query.get(ebid)
    if ebook:
        data = request.json
        ebook.name = data['name']
        ebook.genre = data['genre']
        ebook.content = data['content']
        ebook.description = data['description']
        ebook.authors = data['authors']
        ebook.price = data['price']
        ebook.rental = data['rental']
        db.session.commit()
        return {'message': 'eBook updated successfully'}, 200
    else:
        return {'message': 'eBook not found'}, 404






if __name__ == "__main__":
    app.run(debug=True)