<template>
  <div class="jumbotron vertical-center">
    <div class="container">
      <!-- Bootswatch -->
      <link <!-- rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/sketchy/bootstrap.min.css"
        integrity="sha384-RxqHG2ilm4r6aFRpGmBbGTjsqwfqHOKy1ArsMhHusnRO47jcGqpIQqlQK/kmGy9R" crossorigin="anonymous"
        -- />

      <!-- Bootstrap CSS -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
      <!-- Lux theme CSS -->
      <link href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.0/lux/bootstrap.min.css" rel="stylesheet" />


      <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/superhero/bootstrap.min.css" integrity="sha384-HnTY+mLT0stQlOwD3wcAzSVAZbrBp141qwfR4WfTqVQKSgmcgzk+oP0ieIyrxiFO" crossorigin="anonymous"> -->

      <div class="row">
        <div class="col-sm-12">
          <h1 class="text-center bg-primary text-white" style="border-radius: 10px">
            welcome to e-Library
          </h1>
          <hr />
          <br />

          <!-- b alert messsgae here-->

          <div v-if="bAlertActive">
            {{ msg }}
          </div>

          <!-- here is login container-->

          <div class="container">
            <div class="row justify-content-center">
              <div class="col-md-6">
                <div class="card">
                  <div class="card-header">Login</div>
                  <div class="card-body">
                    <form @submit.prevent="login">
                      <div class="form-group">
                        <label for="email">Email address</label>
                        <input type="email" class="form-control" id="email" v-model="ldata.lemail" required />
                      </div>
                      <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" v-model="ldata.lpassw" required />
                      </div>
                      <button type="submit" class="btn btn-primary">
                        Login
                      </button>

                      <!--modifying the loc of signup-->
                      <span style="margin-right: 20px;"></span>

                      <button type="button" class="btn btn-success btn-sm" v-b-modal.user-modal>
                        new user Signup here
                      </button>


                      <span style="margin-right: 20px;"></span>

                      <button type="button" class="btn btn-success btn-sm" @click="adminlogin">
                        Admin login
                      </button>

                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!--login container ends here-->

          <!-- Add User button -->
         
          <br /><br />
          <!-- this is the place for user login -->

          <!-- Footer -->
          <Footer class="bg-primary text-white text-center" style="border-radius: 10px">Copyright &copy;. All Rights
            Reserved by elib management
            team.</Footer>
        </div>
      </div>

      <!-- Start of Modal 1 -->
      <b-modal ref="addUserModal" id="user-modal" title="Enter the following details" hide-backdrop hide-footer>
        <form @submit.prevent="submitForm">
          <div class="form-group">
            <label for="fullName">Full Name</label>
            <input type="text" class="form-control" id="fullName" v-model="formData.fname" required />
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" v-model="formData.email" required />
          </div>
          <div class="form-group">
            <label for="mobile">Mobile No</label>
            <input type="tel" class="form-control" id="mobile" v-model="formData.mobile" required />
          </div>
          <div class="form-group">
            <label for="designation">Designation</label>
            <select class="form-control" id="designation" v-model="formData.designation" required>
              <option value="">Select Designation</option>
              <option value="student">Student</option>
              <option value="teaching_staff">Teaching Staff</option>
              <option value="non_teaching_staff">Non-Teaching Staff</option>
              <option value="author">Author</option>
            </select>
          </div>

          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="passw" v-model="formData.passw" required />
          </div>

          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </b-modal>
      <!-- End of modal 1 -->
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      formData: {
        fname: "",
        email: "",
        mobile: "",
        designation: "",
        passw: "",
      },

      msg: "",

      actk: "",
      ldata: {
        lemail: "",
        lpassw: "",
      },

      bAlertActive: false,
    };
  },

  methods: {
    submitForm() {
      fetch("http://localhost:5000/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(this.formData),
      })
        .then((response) => {
          if (response.ok) {
            console.log("Form submitted successfully!");
            this.$refs.addUserModal.hide();
            this.msg = "sign up succesfull now you can login";
            this.bAlertActive = true;
            this.formData.fname= "";
            this.formData.email= "";
            this.formData.mobile= "";
            this.formData.designation= "";
            this.formData.passw= "";


            response.json().then((data) => {
              console.log("Data from server:", data);
            });
          } else {
            console.error("Failed to submit form:", response.status);
          }
        })
        .catch((error) => {
          console.error("Error submitting form:", error);
        });
    },

    login() {
      fetch("http://localhost:5000/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(this.ldata),
      })
        .then((response) => {
          if (response.ok) {
            // Handle success response
            console.log("login data from frontend sent succesfully !");
            this.msg = "login data sent succesfull";
            this.bAlertActive = true;

            response.json().then((data) => {
              console.log("Data from server:", data.access_token);
              localStorage.setItem("access_token", data.access_token);
              this.$router.push({ path: "/userdash" });
            });
          } else {
            this.msg = "check email id or password & try again";
            this.bAlertActive = true;

            console.error("Failed to submit form:", response.status);
            // You can handle errors appropriately here
          }
        })
        .catch((error) => {
          console.error("Error submitting form:", error);
          // You can handle errors appropriately here
        });
    },


    adminlogin() {
      fetch("http://localhost:5000/adminlogin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(this.ldata),
      })
        .then((response) => {
          if (response.ok) {
            // Handle success response
            console.log("login data from frontend sent succesfully !");
            this.msg = "admon login data sent succesfull";
            this.bAlertActive = true;

            response.json().then((data) => {
              console.log("Data from server:", data.access_token);
              localStorage.setItem("adminaccess_token", data.access_token);
              this.$router.push({ path: "/admindash" });
            });
          } else {
            this.msg = "check email id or password & try again";
            this.bAlertActive = true;

            console.error("Failed to submit form:", response.status);
            // You can handle errors appropriately here
          }
        })
        .catch((error) => {
          console.error("Error submitting form:", error);
          // You can handle errors appropriately here
        });
    },



  },
};
</script>./Login.vue
