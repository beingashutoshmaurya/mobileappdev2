<template>
<div>
    <div class="upper-banner">
        <div class="logo">
            <!-- Your logo or app name here -->
            Welcome {{ curruser.fullName }}
        </div>

        <div v-if="curruser && curruser.des === 'author'">
            <button type="button" class="btn btn-primary" @click="addEbookModal = true">
                Add Ebook
            </button>
        </div>

        <div>
            <button type="button" class="btn btn-primary" @click="showMessagesModal">
                📬 Messages
            </button>
        </div>

        <div class="search-bar">
            <input type="text" v-model="searchQuery" placeholder="Search books...">
            <button @click="searchBooks">Search</button>
        </div>

        <div class="logout-btn" @click="logout">
            Logout
        </div>

    </div>

    <h2>available book </h2>

    <!-- Book for showcase where we can rent book -->
    <table class="table table-hover">
        <thead>
            <tr>
                <!-- Table header cells -->
                <th scope="col">Title</th>
                <th scope="col">Genre</th>
                <th scope="col">Authors</th>
                <th scope="col">Price</th>
                <th scope="col">Rental (per week)</th>
            </tr>
        </thead>
        <tbody>
            <!-- Table body -->
            <tr v-for="(ebid, index) in avlbook" :key="index">
                <!-- Check if the book is not in reqissl -->
                <template v-if="!reqissl.includes(ebid.id)">
                    <!-- Table data -->
                    <td>{{ ebid.name }}</td>
                    <td>{{ ebid.genre }}</td>
                    <td>{{ ebid.authors }}</td>
                    <td>{{ ebid.price }}</td>
                    <td v-if="!reqbook.includes(ebid.id)">
                        <button @click="rentbook(ebid.id, ebid.name)">Rent @ {{ ebid.rental }}</button>
                    </td>
                    <td v-else>requested</td>
                </template>
            </tr>
        </tbody>

    </table>

    <h2>issued books</h2>

    <!-- Book which are issued -->
    <table class="table table-hover">
        <thead>
            <tr>
                <!-- Table header cells -->
                <th scope="col">Title</th>
                <th scope="col">Genre</th>
                <th scope="col">Authors</th>
                <th scope="col">Issue date</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Table body -->
            <tr v-for="(book, index) in issued" :key="index">
                <!-- Table data -->
                <td>{{ book.name }}</td>
                <td>{{ book.genre }}</td>
                <td>{{ book.authors }}</td>
                <td>{{ book.issueDate }}</td>
                <td>
                    <button @click="readBook(book.content)">Read</button>
                    <button @click="returnBook(book.name)">Return</button>
                </td>
            </tr>
        </tbody>
    </table>

    <!-- search result b modal -->

    <b-modal v-model="showSearchModal" title="Search Results">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">Title</th>
                    <th scope="col">Genre</th>
                    <th scope="col">Authors</th>
                    <th scope="col">Price</th>
                    <th scope="col">Rental (per week)</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(book, index) in searchResults" :key="index">
                    <td>{{ book.name }}</td>
                    <td>{{ book.genre }}</td>
                    <td>{{ book.authors }}</td>
                    <td>{{ book.price }}</td>
                    <td v-if="!reqbook.includes(book.id)">
                        <button @click="rentbook(book.id, book.name)">Rent @ {{ book.rental }}</button>
                    </td>
                    <td v-else>Requested</td>
                </tr>
            </tbody>
        </table>
    </b-modal>

    <!-- Messages Modal -->
    <b-modal v-model="showMessages" title="Messages">
        <ul>
            <li v-for="message in avlmsg" :key="message.sno">{{ message.msg }}</li>
        </ul>
    </b-modal>

    <!-- Modal -->
    <b-modal v-model="addEbookModal" title="Add Ebook">
        <form @submit.prevent="addEbook">
            <b-form-group id="ebid" label="Ebook ID:" label-for="ebid">
                <b-form-input v-model="formData.ebid" required></b-form-input>
            </b-form-group>
            <b-form-group id="name" label="Name:" label-for="name">
                <b-form-input v-model="formData.name" required></b-form-input>
            </b-form-group>
            <b-form-group id="genre" label="Genre:" label-for="genre">
                <b-form-input v-model="formData.genre" required></b-form-input>
            </b-form-group>
            <b-form-group id="name" label="Description:" label-for="description">
                <b-form-input v-model="formData.description" required></b-form-input>
            </b-form-group>

            <b-form-group id="content" label="Content:" label-for="content">
                <b-form-textarea v-model="formData.content" required></b-form-textarea>
            </b-form-group>
            <b-form-group id="authors" label="Authors:" label-for="authors">
                <b-form-input v-model="formData.authors" required></b-form-input>
            </b-form-group>

            <b-form-group id="price" label="Price:" label-for="price">
                <b-form-input v-model="formData.price" required></b-form-input>
            </b-form-group>

            <b-form-group id="rental" label="Rental:" label-for="rental">
                <b-form-input v-model="formData.rental" required></b-form-input>
            </b-form-group>

            <b-button type="submit" variant="primary">Add Ebook</b-button>
            <b-button variant="danger" @click="addEbookModal = false">Cancel</b-button>
        </form>
    </b-modal>

    <!-- Read Book Modal -->
    <b-modal v-model="showReadBookModal" title="Read Book">
        <p>{{bookcon}}</p>
    </b-modal>
</div>
</template>

<script>
import axios from "axios";

export default {
    name: "UserDash",
    data() {
        return {
            bookcon: null,
            accessToken: "",
            curruser: null,
            avlbook: null,
            avlmsg: null,
            addEbookModal: false,
            showMessages: false,
            showReadBookModal: false,
            formData: {
                ebid: "",
                name: "",
                genre: "",
                description: "",
                content: "",
                authors: "",
                price: null,
                rental: null,
                reqissl: null,
            },
            ebookreq: {
                ebid: "",
                name: "",
            },
            reqbook: null,
            issued: null,

            selectedBookContent: "", // To store the content of the selected book
            searchQuery: "",
            showSearchModal: false,
            searchResults: [],
        };
    },
    mounted() {
        this.accessToken = localStorage.getItem("access_token");
        this.fetchProtectedData();
        this.fetchEbook();
        this.fetchreqbook();
        this.fetchissuedbook();
        this.fetchMessages();
        this.fetchbookl();

    },
    methods: {
        fetchProtectedData() {
            axios
                .get("http://127.0.0.1:5000/protected", {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    this.curruser = response.data;
                })
                .catch((error) => {
                    console.error("Error fetching protected data:", error);
                });
        },

        fetchEbook() {
            axios
                .get("http://127.0.0.1:5000/ebooks", {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    this.avlbook = response.data;
                    console.log('Fetching e-book success');
                })
                .catch((error) => {
                    console.error("Error fetching protected data:", error);
                });
        },

        addEbook() {
            fetch("http://127.0.0.1:5000/addebook", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                    body: JSON.stringify(this.formData),
                })
                .then((response) => {
                    if (response.ok) {
                        console.log("Ebook added successfully!");
                        this.formData = {
                            ebid: "",
                            name: "",
                            genre: "",
                            description: "",
                            content: "",
                            authors: "",
                            price: null,
                            rental: null,
                        };
                        this.addEbookModal = false;
                    } else {
                        console.error("Failed to add ebook:", response.status);
                    }
                })
                .catch((error) => {
                    console.error("Error adding ebook:", error);
                });
        },

        rentbook(id, name) {
            const reqbbid = id;
            const reqbnm = name;

            console.log("Buying book id:", id);
            console.log("Buying book name:", name);

            fetch("http://127.0.0.1:5000/rentbookreq", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                    body: JSON.stringify({
                        reqbbid,
                        reqbnm,
                    }),
                })
                .then((response) => {
                    if (response.ok) {
                        console.log("Book adding requested successfully");
                        this.fetchreqbook();
                    } else {
                        console.error("Failed to add ebook:", response.status);
                    }
                })
                .catch((error) => {
                    console.error("Error adding ebook:", error);
                });
        },

        fetchreqbook() {
            axios
                .get("http://127.0.0.1:5000/reqbooks", {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    this.reqbook = response.data;
                    console.log('Fetching e-book success');
                    console.log(response.data);
                })
                .catch((error) => {
                    console.error("Error fetching protected data:", error);
                });
        },

        fetchbookl() {
            axios
                .get("http://127.0.0.1:5000/reqbooksissuel", {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    this.reqissl = response.data;
                    console.log('Fetching issued  e-book list success');
                    console.log(response.data);
                })
                .catch((error) => {
                    console.error("Error fetching protected data:", error);
                });
        },

        logout() {
            localStorage.removeItem("accessToken");
            this.$router.push("/");
        },

        fetchissuedbook() {
            axios
                .get("http://127.0.0.1:5000/issuedbooks", {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    this.issued = response.data;
                    console.log('Fetching issued book success');
                    console.log(response.data);
                })
                .catch((error) => {
                    console.error("Error fetching protected data:", error);
                });
        },

        fetchMessages() {
            axios
                .get("http://127.0.0.1:5000/messages", {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    this.avlmsg = response.data;
                    console.log('Fetching user messages success');
                })
                .catch((error) => {
                    console.error("Error fetching protected data:", error);
                });
        },

        showMessagesModal() {
            this.showMessages = true;
        },

        readBook(book) {
            this.bookcon = book;
            this.showReadBookModal = true;

        },
        searchBooks() {
            if (this.searchQuery.trim() === "") {
                this.searchResults = [];
                this.showSearchModal = false;
                return;
            }

            // Convert search query to lowercase for case-insensitive search
            const searchQueryLower = this.searchQuery.toLowerCase();

            // Filter available books based on book name, genre, or authors matching the search query
            this.searchResults = this.avlbook.filter((book) =>
                book.name.toLowerCase().includes(searchQueryLower) ||
                book.genre.toLowerCase().includes(searchQueryLower) ||
                book.authors.toLowerCase().includes(searchQueryLower)
            );

            // Show the search modal
            this.showSearchModal = true;
        },

        returnBook(sbook) {
            axios
                .delete(`http://127.0.0.1:5000/returnbook/${sbook}`, {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    if (response.status === 200) {
                        // Book returned successfully, update the list of issued books
                        this.fetchissuedbook();
                        console.log('Book returned successfully');
                    } else {
                        console.error('Failed to return book');
                    }
                })
                .catch((error) => {
                    console.error('Error returning book:', error);
                });
        },

    },
};
</script>

<style scoped>
.upper-banner {
    background-color: #333;
    color: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
}

.logo {
    font-size: 1.5rem;
}

.logout-btn {
    cursor: pointer;
}

.search-bar {
    margin: 20px 0;
}
</style>
