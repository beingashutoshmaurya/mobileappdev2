<template>
    <div>
        <p>{{ msg }}</p>
        <button type="button" class = "btn btn-primary">this is button</button>
    </div>
</template>

<script>

import axois from 'axios';


export default {
    name:'Shark',
    data(){
        return{
            msg :  ""
        }
    },
    methods : {
        getResponse(){
            const path = 'http://localhost:8080/shark';
            axois.get(path)
            .then ((res) => {
                console.log(res.data)
                this.msg = res.data;
            })
            .catch ((err) => {
                console.error(err)
            });
        },
    },
    created(){
        this.getResponse();
    }
}

</script>