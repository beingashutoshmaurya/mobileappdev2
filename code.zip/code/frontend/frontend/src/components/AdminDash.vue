<template>
<div>
    <div class="upper-banner">
        <div class="logo">
            <!-- Your logo or app name here -->
            Welcome Admin
        </div>
        <div class="logout-btn" @click="logout">Logout</div>
    </div>

    <!-- Move the buttons outside of the upper-banner -->
    <div class="button-container">
        <b-button @click="modalVisibleIssue = true">Book Issue Request</b-button>
        <b-button @click="modalVisiblePub = true">Book Publish Request</b-button>
        <b-button @click="modalVisibleManageIssue = true">Manage Book Issue</b-button>
        <b-button @click="modalVisibleAddEbook = true">Add Ebook</b-button>
        <b-button @click="modalVisibleAddSection = true">Add Section</b-button>
        <b-button @click="managesec = true">Manage section</b-button>
        <b-button @click="modalVisibleManageEbooks = true">Manage eBooks</b-button>
        

    </div>



    <b-modal v-model="modalVisibleManageEbooks" title="Manage eBooks" centered size="lg">
        <div class="custom-modal-content">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Ebook ID</th>
                        <th>Name</th>
                        <th>Genre</th>
                        <th>Authors</th>
                        <th>Price</th>
                        <th>Rental</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(ebook, index) in ebooks" :key="index">
                        <td>{{ ebook.ebid }}</td>
                        <td>{{ ebook.name }}</td>
                        <td>{{ ebook.genre }}</td>
                        <td>{{ ebook.authors }}</td>
                        <td>{{ ebook.price }}</td>
                        <td>{{ ebook.rental }}</td>
                        <td>
                            <b-button @click="editBook(ebook)">Edit</b-button>
                            <b-button @click="deleteEbook(ebook.ebid)">Delete</b-button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </b-modal>

    <!-- Modal for updating section -->
    <b-modal v-model="modalVisibleUpdate" title="Update Section" centered size="lg">
        <div class="custom-modal-content">
            <div class="form-group">
                <label for="scid">Section ID</label>
                <input type="text" class="form-control" v-model="currsc.scid" disabled>
            </div>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" v-model="currsc.name">
            </div>
            <div class="form-group">
                <label for="desc">Description</label>
                <textarea class="form-control" v-model="currsc.desc"></textarea>
            </div>

            <!-- Buttons for update and delete section -->
            <td><button @click="deleteSection(section.scid)">Delete Section</button></td>

            <button class="btn btn-primary" @click="updateSection">Update</button>
        </div>
    </b-modal>

    <!-- Modal for editing specific section -->
    <b-modal v-model="managesec" title="Manage Sections" centered size="lg">
        <div class="custom-modal-content">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Section ID</th>
                        <th>Name</th>
                        <th>Creation Date</th>
                        <th>Description</th>
                        <th>edit </th>

                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(section, index) in sections" :key="index">
                        <td>{{ section.scid }}</td>
                        <td>{{ section.name }}</td>
                        <td>{{ section.scd }}</td>
                        <td>{{ section.desc }}</td>
                        <td><button @click="udsec(section.scid , section.name , section.scd , section.desc  )">Update Section</button>
                            <button @click="deleteSection(section.scid)">Delete Section</button>
                        </td>

                    </tr>
                </tbody>
            </table>
        </div>
    </b-modal>

    <!-- Modal for adding eBook -->
    <b-modal v-model="modalVisibleAddEbook" title="Add New Ebook" centered size="lg">
        <div class="custom-modal-content">
            <!-- Input fields for eBook details -->
            <div class="form-group">
                <label for="ebid">Ebook ID</label>
                <input type="text" class="form-control" v-model="newEbook.ebid">
            </div>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" v-model="newEbook.name">
            </div>
            <div class="form-group">
                <label for="genre">Genre</label>
                <input type="text" class="form-control" v-model="newEbook.genre">
            </div>
            <div class="form-group">
                <label for="content">Content</label>
                <textarea class="form-control" v-model="newEbook.content"></textarea>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" v-model="newEbook.description"></textarea>
            </div>
            <div class="form-group">
                <label for="authors">Authors</label>
                <input type="text" class="form-control" v-model="newEbook.authors">
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" class="form-control" v-model="newEbook.price">
            </div>
            <div class="form-group">
                <label for="rental">Rental</label>
                <input type="number" class="form-control" v-model="newEbook.rental">
            </div>

            <!-- Button to submit the new eBook -->
            <button class="btn btn-primary" @click="addEbook">Add Ebook</button>
        </div>
    </b-modal>

    <!-- Modal for adding a new section -->
    <b-modal v-model="modalVisibleAddSection" title="Add New Section" centered>
        <div class="custom-modal-content">
            <!-- Input fields for section details -->
            <div class="form-group">
                <label for="scid">Section ID</label>
                <input type="text" class="form-control" v-model="newSection.scid">
            </div>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" v-model="newSection.name">
            </div>
            <div class="form-group">
                <label for="desc">Description</label>
                <textarea class="form-control" v-model="newSection.desc"></textarea>
            </div>

            <!-- Button to submit the new section -->
            <button class="btn btn-primary" @click="addSection">Add Section</button>
        </div>
    </b-modal>

    <b-modal v-model="modalVisibleManageIssue" title="Manage Issued Books" centered size="lg">
        <div class="custom-modal-content">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>s_no</th>

                        <th>Book Name</th>
                        <th>Issued To</th>
                        <th>Issue Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(issue, index) in issueebookn" :key="index">
                        <td>{{ issue.s_no}}</td>
                        <td>{{ issue.name }}</td>
                        <td>{{ issue.usr }}</td>
                        <td>{{ issue.issdt }}</td>
                        <td>
                            <button @click="revokeBook(issue.s_no)">Revoke</button>
                        </td>
                    </tr>
                </tbody>
            </table>
            <!-- Button to revoke all issues older than 7 days -->
            <button @click="revokeAllBooks">Revoke All Older Than 7 Days</button>
        </div>
    </b-modal>

    <!-- its for edit ebook modal -->

    <b-modal v-model="modalVisibleEditBook" title="Edit Book" centered>
        <div class="custom-modal-content">
            <!-- Input fields for book details -->
            <div class="form-group">
                <label for="ebid">Ebook ID</label>
                <input type="text" class="form-control" v-model="currbook.ebid" disabled>
            </div>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" v-model="currbook.name">
            </div>
            <div class="form-group">
                <label for="genre">Genre</label>
                <input type="text" class="form-control" v-model="currbook.genre">
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" v-model="currbook.description"></textarea>
            </div>
            <div class="form-group">
                <label for="authors">Authors</label>
                <input type="text" class="form-control" v-model="currbook.authors">
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" class="form-control" v-model="currbook.price">
            </div>
            <div class="form-group">
                <label for="rental">Rental</label>
                <input type="number" class="form-control" v-model="currbook.rental">
            </div>

            <!-- Button to update the book -->
            <button class="btn btn-primary" @click="updateBook">Update</button>
        </div>
    </b-modal>

    <b-modal v-model="modalVisiblePub" title="Pending Ebook Approval Requests" centered class="modal-lg">
        <p>This is the content of the modal.</p>
        <p>This is for the ebook publishing request.</p>
        <p>which will be accessed later in form of table</p>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>book id</th>
                    <th>Name</th>
                    <th>genre</th>
                    <th>requested user</th>
                    <th>view e-book</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(ebid, index) in reqpubebook" :key="index">
                    <td>{{ ebid.ebid }}</td>
                    <td>{{ ebid.name }}</td>
                    <td>{{ ebid.genre }}</td>
                    <td>{{ ebid.requser }}</td>
                    <td><button @click="showBook(ebid.ebid, ebid.name, ebid.content, ebid.description, ebid.authors, ebid.price, ebid.rental)">view Book</button></td>
                </tr>
            </tbody>
        </table>
    </b-modal>

    <b-modal v-model="modalVisibleIssue" title="Pending Ebook Approval Requests" centered size="lg">
        <div class="custom-modal-content">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>book name</th>
                        <th>requested user</th>
                        <th>request date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(isid, index) in reqissueebook" :key="index">
                        <td>{{ isid.reqebooknm }}</td>
                        <td>{{ isid.requsr }}</td>
                        <td>{{ isid.reqdtm }}</td>
                        <td>
                            <button @click="approveBookIssue(isid.s_no)">Approve</button>
                            <button @click="rejectBookIssue(isid.s_no)">Reject</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </b-modal>

    <b-modal v-model="modalshowBook" title="Current Book Details">
        <h2>book title : {{ currbook.name }}</h2>
        <h2>book authors : {{ currbook.authors }}</h2>
        <h2>book price : {{ currbook.price }}</h2>
        <h2>book rental : {{ currbook.rental }}</h2>
        <h3>book description : {{ currbook.description }}</h3>
        <p>content of book : {{ currbook.content }}</p>
        <button @click="approveBook(currbook.id)">Approve</button>
        <button @click="rejectBook(currbook.id)">Reject</button>
    </b-modal>

    <div>
        <canvas ref="barChart"></canvas>
    </div>

    <div>
        <canvas ref="myChart"></canvas>
    </div>

</div>
</template>

<script>
import axios from 'axios';
import Chart from 'chart.js/auto';

export default {
    name: 'AdminDash',
    data() {
        return {
            accessToken: null,
            reqpubebook: null,
            reqissueebook: null,
            issueebookn:null,
            sections: null,
            modalVisiblePub: false,
            modalVisibleIssue: false,
            modalVisibleEditBook: false,
            modalVisibleManageIssue: false,
            modalVisibleManageEbooks: false,
            modalVisibleStats: false, // New property to control visibility of the statistics modal
            modalshowBook: false,
            modalVisibleUpdate: false,
            currbook: {
                id: '',
                name: '',
                content: '',
                description: '',
                authors: '',
                price: null,
                rental: null
            },
            ebooks: [],
            
            modalVisibleAddEbook: false,
            newEbook: {
                ebid: '',
                name: '',
                genre: '',
                content: '',
                description: '',
                authors: '',
                price: null,
                rental: null
            },
            modalVisibleAddSection: false,
            newSection: {
                scid: '',
                name: '',
                desc: ''
            },
            managesec: false,
            currsc: {
                scid: '',
                name: '',
                desc: ''

            },
            issuanceChart: null,
            chartData: null
        };
    },
    mounted() {
        this.accessToken = localStorage.getItem('adminaccess_token');
        this.fetchEbookissuereq();
        this.fetchebookpubreq();
        this.fetchebookissuereq();
        this.fetchIssuedBooks();
        this.fetchSections();
        this.fetchEbooks();
        this.fetchUsrIssue();
        this.fetchData();

    },
    methods: {

        async fetchData() {
            try {
                const response = await axios.get('http://localhost:5000/userissuedata_ad_m');
                // Assuming response.data is already in the correct format [{month: 'January', issuedBooksCount: 5}, ...]
                this.chartData = response.data;
                this.renderChartb();
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        },

        renderChartb() {
            const ctx = this.$refs.myChart.getContext('2d');
            const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

            // Initialize arrays for chart labels and data
            const labels = [];
            const data = [];

            // Loop through months array to ensure consistent order
            months.forEach(month => {
                // Find the corresponding entry in chartData, if exists
                const monthData = this.chartData.find(entry => entry.month === month);
                // Push label and data (or 0 if data for the month is not available)
                labels.push(month);
                data.push(monthData ? monthData.issuedBooksCount : 0);
            });

            // Render the chart
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Number of Books Issued',
                        data: data,
                        backgroundColor: 'rgba(54, 162, 235, 0.6)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                    }
                }
            });
        },

        async fetchUsrIssue() {
            try {
                const response = await fetch("http://localhost:5000/userissuedata_ad", {
                    method: "GET",
                    headers: {
                        Authorization: `Bearer ${this.at}`, // Assuming you have an access token
                    },
                });

                if (response.ok) {
                    const data = await response.json();
                    this.processUsrIssue(data);
                } else {
                    console.error("Failed to fetch user issue data");
                }
            } catch (error) {
                console.error("Error fetching user issue data:", error);
            }
        },
        processUsrIssue(data) {
            // Process the fetched data to get counts of issued books per user
            // Assuming data is an array of objects containing user and issued book count
            const labels = data.map(item => item.user);
            const values = data.map(item => item.issuedBooksCount);

            this.userIssueData = {
                labels,
                values
            };

            // Call a method to render the bar chart
            this.renderBarChart();
        },
        renderBarChart() {
            // Render the bar chart using Chart.js
            const ctx = this.$refs.barChart.getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: this.userIssueData.labels,
                    datasets: [{
                        label: 'Number of Issued Books',
                        data: this.userIssueData.values,
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        },

        editBook(ebook) {
            this.currbook = {
                ebid: ebook.ebid,
                name: ebook.name,
                genre: ebook.genre,
                description: ebook.description,
                authors: ebook.authors,
                price: ebook.price,
                rental: ebook.rental,
                content: ebook.content
            };
            this.modalVisibleEditBook = true;
        },

        updateBook() {
            axios
                .put(`http://127.0.0.1:5000/updateEbook/${this.currbook.ebid}`, this.currbook, {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then(() => {
                    this.modalVisibleEditBook = false;
                    this.fetchEbooks();
                })
                .catch((error) => {
                    console.error("Error updating eBook:", error);
                });
        },

        deleteEbook(ebid) {
            axios
                .delete(`http://127.0.0.1:5000/deleteEbook/${ebid}`, {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then(() => {
                    // Remove the deleted eBook from the list
                    this.ebooks = this.ebooks.filter(ebook => ebook.ebid !== ebid);
                })
                .catch((error) => {
                    console.error("Error deleting eBook:", error);
                });
        },

        fetchEbooks() {
            axios.get('http://127.0.0.1:5000/allebooks')
                .then(response => {
                    this.ebooks = response.data;
                })
                .catch(error => {
                    console.error('Error fetching eBooks:', error);
                });
        },

        fetchSections() {
            axios.get('http://127.0.0.1:5000/sections')
                .then(response => {
                    this.sections = response.data;
                })
                .catch(error => {
                    console.error('Error fetching sections:', error);
                });
        },
        udsec(id, nm, scd, dsc) {
            this.currsc.scid = id;
            this.currsc.name = nm;
            this.currsc.desc = dsc;
            this.modalVisibleUpdate = true;
        },

        addSection() {
            axios
                .post('http://127.0.0.1:5000/addSection', this.newSection, {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    // Handle success, e.g., close modal, fetch updated data, etc.
                    this.modalVisibleAddSection = false;
                    // Additional actions if needed after adding section successfully
                })
                .catch((error) => {
                    console.error('Error adding section:', error);
                    // Handle error, e.g., show error message to user
                });
        },

        addEbook() {
            axios
                .post('http://127.0.0.1:5000/addEbookad', this.newEbook, {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    // Handle success, e.g., close modal, fetch updated data, etc.
                    this.modalVisibleAddEbook = false;
                    // Additional actions if needed after adding eBook successfully
                })
                .catch((error) => {
                    console.error('Error adding eBook:', error);
                    // Handle error, e.g., show error message to user
                });
        },

        showStats() {
            axios
                .get("http://127.0.0.1:5000/bookissuancestats", {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    const statsData = response.data;
                    // Extract labels (user names) and values (number of books issued)
                    const labels = statsData.map((data) => data.usr);
                    const values = statsData.map((data) => data.num_books);

                    // Get the canvas element where the chart will be rendered
                    const ctx = document.getElementById('issuanceChart').getContext('2d');

                    // Check if there's an existing chart instance, destroy it to prevent memory leaks
                    if (this.issuanceChart) {
                        this.issuanceChart.destroy();
                    }

                    // Render the new chart using Chart.js
                    this.issuanceChart = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: labels,
                            datasets: [{
                                label: 'Number of Books Issued',
                                data: values,
                                backgroundColor: 'rgba(54, 162, 235, 0.5)', // Customize the color as needed
                                borderColor: 'rgba(54, 162, 235, 1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });

                    // Show the statistics modal
                    this.modalVisibleStats = true;
                })
                .catch((error) => {
                    console.error("Error fetching book issuance statistics:", error);
                    // Add error handling logic here, such as displaying an error message to the user
                });
        },

        fetchEbookissuereq() {
            axios
                .get("http://127.0.0.1:5000/ebookissuereq", {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    this.reqpubebook = response.data;
                })
                .catch((error) => {
                    console.error("Error fetching protected data:", error);
                });
        },
        fetchebookpubreq() {
            axios
                .get("http://127.0.0.1:5000/ebookpubappreq", {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    this.reqpubebook = response.data;
                })
                .catch((error) => {
                    console.error("Error fetching protected data:", error);
                });
        },
        fetchebookissuereq() {
            axios
                .get("http://127.0.0.1:5000/ebookissuereq", {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    this.reqissueebook = response.data;
                })
                .catch((error) => {
                    console.error("Error fetching protected data:", error);
                });
        },
        logout() {
            localStorage.removeItem('adminaccess_token');
            this.$router.push('/');
        },
        showBook(i, n, c, d, a, p, r) {
            this.currbook.id = i;
            this.currbook.name = n;
            this.currbook.content = c;
            this.currbook.description = d;
            this.currbook.authors = a;
            this.currbook.price = p;
            this.currbook.rental = r;
            this.modalshowBook = true;
        },
        approveBook(e) {
            axios
                .get(`http://127.0.0.1:5000/approveBook/${e}`, {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    this.reqpubebook = response.data;
                    this.modalshowBook = false;
                    this.fetchebookpubreq();
                    this.modalVisiblePub = true;
                })
                .catch((error) => {
                    console.error("Error fetching protected data:", error);
                });
        },
        rejectBook(e) {
            axios
                .get(`http://127.0.0.1:5000/rejectBook/${e}`, {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    this.reqpubebook = response.data;
                    this.modalshowBook = false;
                    this.fetchebookpubreq();
                    this.modalVisiblePub = true;
                })
                .catch((error) => {
                    console.error("Error fetching protected data:", error);
                });
        },

        revokeBook(issueId) {
            axios
                .delete(`http://127.0.0.1:5000/revokeBook/${issueId}`, {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then(() => {
                    this.fetchebookissuereq();

                })
                .catch((error) => {
                    console.error("Error revoking book:", error);
                });
        },

        revokeAllBooks() {
            axios
                .delete(`http://127.0.0.1:5000/revokeAllBooks`, {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then(() => {
                    // After revoking all books, fetch the updated list of issued books
                    this.fetchebookissuereq();

                })
                .catch((error) => {
                    console.error("Error revoking all books:", error);
                });
        },

        approveBookIssue(e) {
            axios
                .get(`http://127.0.0.1:5000/approveBookissue/${e}`, {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    // Remove the approved request from reqissueebook
                    this.reqissueebook = this.reqissueebook.filter(item => item.s_no !== e);

                    // Check if reqissueebook is empty
                    if (this.reqissueebook.length === 0) {
                        // Close the modal if reqissueebook is empty
                        this.modalVisibleIssue = false;
                    }
                })
                .catch((error) => {
                    console.error("Error fetching protected data:", error);
                });
        },

        rejectBookIssue(e) {
            axios
                .get(`http://127.0.0.1:5000/rejectBookissue/${e}`, {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    this.reqissueebook = this.reqissueebook.filter(item => item.s_no !== e);
                    if (this.reqissueebook.length === 0) {
                        this.modalVisibleIssue = false;
                    }
                })
                .catch((error) => {

                });
        },

        fetchIssuedBooks() {
            axios
                .get("http://127.0.0.1:5000/issuedbooksad", {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then((response) => {
                    this.issueebookn = response.data;
                })
                .catch((error) => {
                    console.error("Error fetching issued books:", error);
                });
        },

        updateSection() {
            axios
                .put(`http://127.0.0.1:5000/updateSection/${this.currsc.scid}`, this.currsc, {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then(() => {
                    // After successfully updating the section, fetch the updated list of sections
                    this.fetchSections();
                    // Close the update section modal
                    this.modalVisibleUpdate = false;
                })
                .catch((error) => {
                    console.error("Error updating section:", error);
                });
        },

        deleteSection(scid) {
            axios
                .delete(`http://127.0.0.1:5000/deleteSection/${scid}`, {
                    headers: {
                        Authorization: `Bearer ${this.accessToken}`,
                    },
                })
                .then(() => {
                    // After successfully deleting the section, fetch the updated list of sections
                    this.fetchSections();
                })
                .catch((error) => {
                    console.error("Error deleting section:", error);
                });
        },

    }
}
</script>

<style scoped>
.upper-banner {
    background-color: #333;
    color: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
}

.logo {
    font-size: 1.5rem;
}

.logout-btn {
    cursor: pointer;
}

.custom-modal-content {
    width: 80%;
    /* Adjust width as needed */
    max-width: 800px;
    /* Example max-width */
    margin: 0 auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.button-container {
    margin: 20px 0;
}

.chart-container {
    width: 80%;
    margin: 0 auto;
    padding: 20px;
}
</style>
